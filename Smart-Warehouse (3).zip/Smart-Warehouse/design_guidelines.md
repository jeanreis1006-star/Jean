# Design Guidelines: Almoxarifado Inteligente

## Brand Identity

**Purpose**: Warehouse inventory management system for tracking stock, equipment, and supplies efficiently.

**Visual Direction**: **Professional/Utilitarian** - Clean, data-dense, scannable interfaces with emphasis on clarity and speed. Trust and efficiency over decoration. Think airport departure boards meets modern SaaS tools.

**Memorable Element**: Vibrant status badges (in-stock green, low-stock amber, out-of-stock red) that make inventory health immediately scannable at a glance.

**Language**: Portuguese (pt-BR)

## Navigation Architecture

**Root Navigation**: Tab Bar (4 tabs) with floating action button for primary action

**Tabs**:
1. **Inventário** (Home) - Main inventory list
2. **Relatórios** - Reports and analytics
3. **Configurações** - Settings and account
4. **Floating Action Button** - Quick Add/Scan item (camera icon)

## Screen Specifications

### 1. Inventário (Home)
**Purpose**: Browse and search all inventory items

**Layout**:
- Header: Transparent, search bar, filter button (right)
- Content: Scrollable list of inventory cards
- Safe area: top = headerHeight + 24, bottom = tabBarHeight + 24

**Components**:
- Search bar (sticky in header)
- Inventory cards showing: item name, SKU, quantity badge, location tag, thumbnail image
- Empty state: empty-inventory.png illustration

### 2. Item Details (Modal)
**Purpose**: View/edit individual item information

**Layout**:
- Header: Default, close button (left), edit button (right), title = item name
- Content: Scrollable form
- Safe area: top = 24, bottom = 24

**Components**:
- Item image (large)
- Form fields: Name, SKU, Category dropdown, Quantity stepper, Min quantity, Location, Supplier, Notes
- Delete button (destructive, bottom)

### 3. Quick Add/Scan (Modal)
**Purpose**: Rapidly add items via camera scan or manual entry

**Layout**:
- Header: Default, cancel button (left), title = "Adicionar Item"
- Content: Camera view OR scrollable form
- Submit button: In header (right, "Salvar")
- Safe area: top = 24, bottom = 24

**Components**:
- Camera viewfinder (barcode/QR scanner)
- Switch to manual entry button
- Form (when manual): Name, Quantity, Location (required fields only)

### 4. Relatórios (Reports Tab)
**Purpose**: View inventory analytics and export data

**Layout**:
- Header: Default, title = "Relatórios", export button (right)
- Content: Scrollable
- Safe area: top = 24, bottom = tabBarHeight + 24

**Components**:
- Summary cards: Total Items, Low Stock Alerts, Last Updated
- Charts: Stock levels by category (bar chart), Movement history (line graph)
- Quick filters: Last 7 days, 30 days, 90 days

### 5. Configurações (Settings Tab)
**Purpose**: App preferences and account management

**Layout**:
- Header: Default, title = "Configurações"
- Content: Scrollable list
- Safe area: top = 24, bottom = tabBarHeight + 24

**Components**:
- Profile section: Avatar, display name, warehouse location
- Preferences: Low stock threshold, Notifications toggle, Language
- Account: Sign out, Delete account (nested)

### 6. Login/Signup
**Purpose**: Authenticate users (multi-user business context requires auth)

**Layout**:
- Header: None
- Content: Centered form
- Safe area: top = insets.top + 40, bottom = insets.bottom + 40

**Components**:
- App logo/name (large, top)
- SSO buttons: "Entrar com Google", "Entrar com Apple"
- Privacy policy and terms links (bottom, small)

## Color Palette

**Primary**: #0066CC (trustworthy blue, slightly deeper than theme_color)
**Primary Dark**: #004C99
**Background**: #F5F7FA (soft cool gray)
**Surface**: #FFFFFF
**Text Primary**: #1A1D1F
**Text Secondary**: #6F767E
**Border**: #E4E7EB

**Status Colors**:
- Success (in-stock): #00A86B (vibrant green)
- Warning (low-stock): #F59E0B (amber)
- Error (out-of-stock): #DC2626 (red)

## Typography

**Font**: System (SF Pro for iOS, Roboto for Android)

**Type Scale**:
- Large Title: 34pt, Bold (screen titles)
- Title: 20pt, Semibold (section headers)
- Body: 16pt, Regular (default text)
- Subhead: 14pt, Medium (labels, metadata)
- Caption: 12pt, Regular (timestamps, SKUs)

## Visual Design

- Inventory cards: white surface, 1px border (#E4E7EB), 8px corner radius, no shadow
- Status badges: 6px corner radius, medium font weight, uppercase text
- Floating action button: Primary color, white icon, shadow (offset: 0/2, opacity: 0.15, radius: 8)
- Icons: Feather icons (package, barcode, trending-up, settings)
- All touchable elements: 0.6 opacity on press

## Assets to Generate

1. **icon.png** - Warehouse box icon in primary blue, simple geometric - Device home screen
2. **splash-icon.png** - Same warehouse icon - Launch screen
3. **empty-inventory.png** - Empty shelves/warehouse illustration, muted colors - Inventário screen when no items
4. **barcode-placeholder.png** - Barcode scanner guide/frame - Quick Add/Scan screen
5. **avatar-default.png** - Generic user silhouette in circle - Profile/Settings screen