export type StockStatus = "in_stock" | "low_stock" | "out_of_stock";

export interface InventoryItem {
  id: string;
  name: string;
  sku: string;
  quantity: number;
  minQuantity: number;
  category: string;
  location: string;
  supplier?: string;
  notes?: string;
  imageUri?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
}

export const CATEGORIES: Category[] = [
  { id: "tools", name: "Ferramentas", icon: "tool" },
  { id: "materials", name: "Materiais", icon: "box" },
  { id: "equipment", name: "Equipamentos", icon: "settings" },
  { id: "consumables", name: "Consumíveis", icon: "package" },
  { id: "safety", name: "Segurança", icon: "shield" },
  { id: "electronics", name: "Eletrônicos", icon: "cpu" },
  { id: "other", name: "Outros", icon: "archive" },
];

export const LOCATIONS = [
  "Prateleira A1",
  "Prateleira A2",
  "Prateleira A3",
  "Prateleira B1",
  "Prateleira B2",
  "Prateleira B3",
  "Depósito Principal",
  "Depósito Secundário",
  "Área de Expedição",
  "Área de Recebimento",
];

export function getStockStatus(item: InventoryItem): StockStatus {
  if (item.quantity === 0) return "out_of_stock";
  if (item.quantity <= item.minQuantity) return "low_stock";
  return "in_stock";
}

export function generateSKU(): string {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let sku = "ALM-";
  for (let i = 0; i < 6; i++) {
    sku += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return sku;
}
