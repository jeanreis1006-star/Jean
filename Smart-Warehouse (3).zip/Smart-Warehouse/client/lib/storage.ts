import AsyncStorage from "@react-native-async-storage/async-storage";
import { InventoryItem, generateSKU } from "@/types/inventory";

const INVENTORY_KEY = "@almoxarifado:inventory";
const SETTINGS_KEY = "@almoxarifado:settings";

export interface AppSettings {
  lowStockThreshold: number;
  notificationsEnabled: boolean;
  warehouseName: string;
  userName: string;
}

const DEFAULT_SETTINGS: AppSettings = {
  lowStockThreshold: 5,
  notificationsEnabled: true,
  warehouseName: "Almoxarifado Principal",
  userName: "Usuário",
};

export async function getInventory(): Promise<InventoryItem[]> {
  try {
    const data = await AsyncStorage.getItem(INVENTORY_KEY);
    if (data) {
      return JSON.parse(data);
    }
    return [];
  } catch (error) {
    console.error("Error loading inventory:", error);
    return [];
  }
}

export async function saveInventory(items: InventoryItem[]): Promise<void> {
  try {
    await AsyncStorage.setItem(INVENTORY_KEY, JSON.stringify(items));
  } catch (error) {
    console.error("Error saving inventory:", error);
    throw error;
  }
}

export async function addItem(
  item: Omit<InventoryItem, "id" | "sku" | "createdAt" | "updatedAt">
): Promise<InventoryItem> {
  const items = await getInventory();
  const newItem: InventoryItem = {
    ...item,
    id: Date.now().toString(),
    sku: generateSKU(),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  items.push(newItem);
  await saveInventory(items);
  return newItem;
}

export async function updateItem(
  id: string,
  updates: Partial<InventoryItem>
): Promise<InventoryItem | null> {
  const items = await getInventory();
  const index = items.findIndex((item) => item.id === id);
  if (index === -1) return null;

  items[index] = {
    ...items[index],
    ...updates,
    updatedAt: new Date().toISOString(),
  };
  await saveInventory(items);
  return items[index];
}

export async function deleteItem(id: string): Promise<boolean> {
  const items = await getInventory();
  const filtered = items.filter((item) => item.id !== id);
  if (filtered.length === items.length) return false;
  await saveInventory(filtered);
  return true;
}

export async function getSettings(): Promise<AppSettings> {
  try {
    const data = await AsyncStorage.getItem(SETTINGS_KEY);
    if (data) {
      return { ...DEFAULT_SETTINGS, ...JSON.parse(data) };
    }
    return DEFAULT_SETTINGS;
  } catch (error) {
    console.error("Error loading settings:", error);
    return DEFAULT_SETTINGS;
  }
}

export async function saveSettings(
  settings: Partial<AppSettings>
): Promise<AppSettings> {
  try {
    const current = await getSettings();
    const updated = { ...current, ...settings };
    await AsyncStorage.setItem(SETTINGS_KEY, JSON.stringify(updated));
    return updated;
  } catch (error) {
    console.error("Error saving settings:", error);
    throw error;
  }
}

export async function clearAllData(): Promise<void> {
  try {
    await AsyncStorage.multiRemove([INVENTORY_KEY, SETTINGS_KEY]);
  } catch (error) {
    console.error("Error clearing data:", error);
    throw error;
  }
}
