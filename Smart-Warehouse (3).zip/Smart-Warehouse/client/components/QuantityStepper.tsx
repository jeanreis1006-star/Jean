import React from "react";
import { View, StyleSheet, Pressable } from "react-native";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { BorderRadius, Spacing } from "@/constants/theme";

interface QuantityStepperProps {
  label: string;
  value: number;
  onChange: (value: number) => void;
  min?: number;
  max?: number;
}

export function QuantityStepper({
  label,
  value,
  onChange,
  min = 0,
  max = 9999,
}: QuantityStepperProps) {
  const { theme } = useTheme();

  const handleDecrease = () => {
    if (value > min) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      onChange(value - 1);
    }
  };

  const handleIncrease = () => {
    if (value < max) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      onChange(value + 1);
    }
  };

  return (
    <View style={styles.container}>
      <ThemedText style={[styles.label, { color: theme.textSecondary }]}>
        {label}
      </ThemedText>
      <View
        style={[
          styles.stepper,
          {
            backgroundColor: theme.backgroundDefault,
            borderColor: theme.border,
          },
        ]}
      >
        <Pressable
          onPress={handleDecrease}
          style={({ pressed }) => [
            styles.button,
            { opacity: pressed ? 0.6 : value <= min ? 0.3 : 1 },
          ]}
          disabled={value <= min}
          testID="button-decrease"
        >
          <Feather name="minus" size={20} color={theme.text} />
        </Pressable>

        <View style={styles.valueContainer}>
          <ThemedText style={styles.value}>{value}</ThemedText>
        </View>

        <Pressable
          onPress={handleIncrease}
          style={({ pressed }) => [
            styles.button,
            { opacity: pressed ? 0.6 : value >= max ? 0.3 : 1 },
          ]}
          disabled={value >= max}
          testID="button-increase"
        >
          <Feather name="plus" size={20} color={theme.text} />
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: Spacing.lg,
  },
  label: {
    fontSize: 14,
    fontWeight: "500",
    marginBottom: Spacing.sm,
  },
  stepper: {
    flexDirection: "row",
    alignItems: "center",
    height: 48,
    borderRadius: BorderRadius.sm,
    borderWidth: 1,
  },
  button: {
    width: 48,
    height: "100%",
    alignItems: "center",
    justifyContent: "center",
  },
  valueContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  value: {
    fontSize: 20,
    fontWeight: "600",
  },
});
