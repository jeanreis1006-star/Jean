import React from "react";
import { View, StyleSheet, Pressable, Image } from "react-native";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from "react-native-reanimated";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";

import { ThemedText } from "@/components/ThemedText";
import { StatusBadge } from "@/components/StatusBadge";
import { useTheme } from "@/hooks/useTheme";
import { BorderRadius, Spacing, Typography } from "@/constants/theme";
import { InventoryItem, getStockStatus, CATEGORIES } from "@/types/inventory";

interface InventoryCardProps {
  item: InventoryItem;
  onPress: () => void;
}

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

export function InventoryCard({ item, onPress }: InventoryCardProps) {
  const { theme } = useTheme();
  const scale = useSharedValue(1);
  const status = getStockStatus(item);
  const category = CATEGORIES.find((c) => c.id === item.category);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const handlePressIn = () => {
    scale.value = withSpring(0.98, { damping: 15, stiffness: 300 });
  };

  const handlePressOut = () => {
    scale.value = withSpring(1, { damping: 15, stiffness: 300 });
  };

  const handlePress = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    onPress();
  };

  return (
    <AnimatedPressable
      onPress={handlePress}
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
      style={[
        styles.card,
        {
          backgroundColor: theme.backgroundDefault,
          borderColor: theme.cardBorder,
        },
        animatedStyle,
      ]}
      testID={`card-item-${item.id}`}
    >
      <View style={styles.content}>
        <View
          style={[
            styles.thumbnail,
            { backgroundColor: theme.backgroundSecondary },
          ]}
        >
          {item.imageUri ? (
            <Image source={{ uri: item.imageUri }} style={styles.image} />
          ) : (
            <Feather
              name={(category?.icon as any) || "package"}
              size={24}
              color={theme.textSecondary}
            />
          )}
        </View>

        <View style={styles.info}>
          <ThemedText style={styles.name} numberOfLines={1}>
            {item.name}
          </ThemedText>
          <ThemedText
            style={[styles.sku, { color: theme.textSecondary }]}
            numberOfLines={1}
          >
            {item.sku}
          </ThemedText>
          <View style={styles.locationRow}>
            <Feather
              name="map-pin"
              size={12}
              color={theme.textSecondary}
              style={styles.locationIcon}
            />
            <ThemedText
              style={[styles.location, { color: theme.textSecondary }]}
              numberOfLines={1}
            >
              {item.location}
            </ThemedText>
          </View>
        </View>

        <View style={styles.right}>
          <View style={styles.quantityContainer}>
            <ThemedText style={[styles.quantity, { color: theme.text }]}>
              {item.quantity}
            </ThemedText>
            <ThemedText
              style={[styles.quantityLabel, { color: theme.textSecondary }]}
            >
              un.
            </ThemedText>
          </View>
          <StatusBadge status={status} />
        </View>
      </View>
    </AnimatedPressable>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: BorderRadius.sm,
    borderWidth: 1,
    marginBottom: Spacing.md,
  },
  content: {
    flexDirection: "row",
    padding: Spacing.md,
    alignItems: "center",
  },
  thumbnail: {
    width: 56,
    height: 56,
    borderRadius: BorderRadius.sm,
    alignItems: "center",
    justifyContent: "center",
    marginRight: Spacing.md,
  },
  image: {
    width: 56,
    height: 56,
    borderRadius: BorderRadius.sm,
  },
  info: {
    flex: 1,
    marginRight: Spacing.md,
  },
  name: {
    fontSize: 16,
    fontWeight: "600",
    marginBottom: 2,
  },
  sku: {
    ...Typography.caption,
    marginBottom: 4,
  },
  locationRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  locationIcon: {
    marginRight: 4,
  },
  location: {
    ...Typography.caption,
    flex: 1,
  },
  right: {
    alignItems: "flex-end",
  },
  quantityContainer: {
    flexDirection: "row",
    alignItems: "baseline",
    marginBottom: Spacing.xs,
  },
  quantity: {
    fontSize: 24,
    fontWeight: "700",
  },
  quantityLabel: {
    ...Typography.caption,
    marginLeft: 2,
  },
});
