import React from "react";
import { View, StyleSheet, ViewStyle } from "react-native";
import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { BorderRadius, Spacing } from "@/constants/theme";
import { StockStatus } from "@/types/inventory";

interface StatusBadgeProps {
  status: StockStatus;
  style?: ViewStyle;
}

const STATUS_CONFIG = {
  in_stock: {
    label: "EM ESTOQUE",
    lightBg: "#E6F7F0",
    darkBg: "#0D3D2D",
  },
  low_stock: {
    label: "ESTOQUE BAIXO",
    lightBg: "#FEF3C7",
    darkBg: "#3D2F0D",
  },
  out_of_stock: {
    label: "SEM ESTOQUE",
    lightBg: "#FEE2E2",
    darkBg: "#3D0D0D",
  },
};

export function StatusBadge({ status, style }: StatusBadgeProps) {
  const { theme, isDark } = useTheme();
  const config = STATUS_CONFIG[status];

  const getStatusColor = () => {
    switch (status) {
      case "in_stock":
        return theme.success;
      case "low_stock":
        return theme.warning;
      case "out_of_stock":
        return theme.error;
    }
  };

  return (
    <View
      style={[
        styles.badge,
        {
          backgroundColor: isDark ? config.darkBg : config.lightBg,
        },
        style,
      ]}
    >
      <ThemedText
        style={[
          styles.text,
          {
            color: getStatusColor(),
          },
        ]}
      >
        {config.label}
      </ThemedText>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.xs,
    alignSelf: "flex-start",
  },
  text: {
    fontSize: 10,
    fontWeight: "600",
    letterSpacing: 0.5,
  },
});
