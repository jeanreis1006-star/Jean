import React, { useState } from "react";
import { View, StyleSheet, Alert, Pressable } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { useNavigation } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";

import { KeyboardAwareScrollViewCompat } from "@/components/KeyboardAwareScrollViewCompat";
import { FormInput } from "@/components/FormInput";
import { SelectInput } from "@/components/SelectInput";
import { QuantityStepper } from "@/components/QuantityStepper";
import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius } from "@/constants/theme";
import { CATEGORIES, LOCATIONS } from "@/types/inventory";
import { addItem } from "@/lib/storage";
import { RootStackParamList } from "@/navigation/RootStackNavigator";

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;

export default function AddItemScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const navigation = useNavigation<NavigationProp>();
  const { theme } = useTheme();

  const [name, setName] = useState("");
  const [category, setCategory] = useState("");
  const [location, setLocation] = useState("");
  const [quantity, setQuantity] = useState(1);
  const [minQuantity, setMinQuantity] = useState(5);
  const [supplier, setSupplier] = useState("");
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);

  const categoryOptions = CATEGORIES.map((cat) => ({
    value: cat.id,
    label: cat.name,
    icon: cat.icon as keyof typeof Feather.glyphMap,
  }));

  const locationOptions = LOCATIONS.map((loc) => ({
    value: loc,
    label: loc,
  }));

  const handleSave = async () => {
    if (!name.trim()) {
      Alert.alert("Erro", "Por favor, insira o nome do item.");
      return;
    }
    if (!category) {
      Alert.alert("Erro", "Por favor, selecione uma categoria.");
      return;
    }
    if (!location) {
      Alert.alert("Erro", "Por favor, selecione uma localização.");
      return;
    }

    setSaving(true);
    try {
      await addItem({
        name: name.trim(),
        category,
        location,
        quantity,
        minQuantity,
        supplier: supplier.trim() || undefined,
        notes: notes.trim() || undefined,
      });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      navigation.goBack();
    } catch (error) {
      console.error("Error saving item:", error);
      Alert.alert("Erro", "Não foi possível salvar o item. Tente novamente.");
    } finally {
      setSaving(false);
    }
  };

  React.useLayoutEffect(() => {
    navigation.setOptions({
      headerRight: () => (
        <Pressable
          onPress={handleSave}
          disabled={saving}
          style={({ pressed }) => ({ opacity: pressed || saving ? 0.5 : 1 })}
          hitSlop={8}
          testID="button-save"
        >
          <ThemedText style={{ color: theme.primary, fontWeight: "600" }}>
            {saving ? "Salvando..." : "Salvar"}
          </ThemedText>
        </Pressable>
      ),
    });
  }, [navigation, name, category, location, quantity, minQuantity, supplier, notes, saving]);

  return (
    <KeyboardAwareScrollViewCompat
      style={[styles.container, { backgroundColor: theme.backgroundRoot }]}
      contentContainerStyle={[
        styles.content,
        {
          paddingTop: headerHeight + Spacing.xl,
          paddingBottom: insets.bottom + Spacing.xl,
        },
      ]}
    >
      <View
        style={[
          styles.section,
          {
            backgroundColor: theme.backgroundDefault,
            borderColor: theme.cardBorder,
          },
        ]}
      >
        <ThemedText style={[styles.sectionTitle, { color: theme.textSecondary }]}>
          Informações Básicas
        </ThemedText>

        <FormInput
          label="Nome do Item *"
          value={name}
          onChangeText={setName}
          placeholder="Ex: Parafuso Phillips 4mm"
          autoCapitalize="words"
          testID="input-name"
        />

        <SelectInput
          label="Categoria *"
          value={category}
          options={categoryOptions}
          onChange={setCategory}
          placeholder="Selecione uma categoria"
        />

        <SelectInput
          label="Localização *"
          value={location}
          options={locationOptions}
          onChange={setLocation}
          placeholder="Selecione uma localização"
        />
      </View>

      <View
        style={[
          styles.section,
          {
            backgroundColor: theme.backgroundDefault,
            borderColor: theme.cardBorder,
          },
        ]}
      >
        <ThemedText style={[styles.sectionTitle, { color: theme.textSecondary }]}>
          Quantidade
        </ThemedText>

        <QuantityStepper
          label="Quantidade Atual"
          value={quantity}
          onChange={setQuantity}
          min={0}
        />

        <QuantityStepper
          label="Quantidade Mínima (Alerta)"
          value={minQuantity}
          onChange={setMinQuantity}
          min={0}
        />
      </View>

      <View
        style={[
          styles.section,
          {
            backgroundColor: theme.backgroundDefault,
            borderColor: theme.cardBorder,
          },
        ]}
      >
        <ThemedText style={[styles.sectionTitle, { color: theme.textSecondary }]}>
          Informações Adicionais
        </ThemedText>

        <FormInput
          label="Fornecedor"
          value={supplier}
          onChangeText={setSupplier}
          placeholder="Nome do fornecedor (opcional)"
          autoCapitalize="words"
          testID="input-supplier"
        />

        <FormInput
          label="Observações"
          value={notes}
          onChangeText={setNotes}
          placeholder="Notas adicionais (opcional)"
          multiline
          numberOfLines={3}
          style={styles.notesInput}
          testID="input-notes"
        />
      </View>
    </KeyboardAwareScrollViewCompat>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    paddingHorizontal: Spacing.lg,
  },
  section: {
    borderRadius: BorderRadius.sm,
    borderWidth: 1,
    padding: Spacing.lg,
    marginBottom: Spacing.lg,
  },
  sectionTitle: {
    fontSize: 13,
    fontWeight: "600",
    textTransform: "uppercase",
    letterSpacing: 0.5,
    marginBottom: Spacing.lg,
  },
  notesInput: {
    height: 80,
    textAlignVertical: "top",
    paddingTop: Spacing.md,
  },
});
