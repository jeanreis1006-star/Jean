import React, { useState, useCallback } from "react";
import { View, ScrollView, StyleSheet, RefreshControl } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { useBottomTabBarHeight } from "@react-navigation/bottom-tabs";
import { useFocusEffect } from "@react-navigation/native";
import Animated, { FadeInDown } from "react-native-reanimated";

import { SummaryCard } from "@/components/SummaryCard";
import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius } from "@/constants/theme";
import { InventoryItem, getStockStatus, CATEGORIES } from "@/types/inventory";
import { getInventory } from "@/lib/storage";

export default function ReportsScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const tabBarHeight = useBottomTabBarHeight();
  const { theme } = useTheme();

  const [items, setItems] = useState<InventoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const loadData = useCallback(async () => {
    try {
      const data = await getInventory();
      setItems(data);
    } catch (error) {
      console.error("Error loading data:", error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      loadData();
    }, [loadData])
  );

  const handleRefresh = () => {
    setRefreshing(true);
    loadData();
  };

  const totalItems = items.length;
  const lowStockItems = items.filter(
    (item) => getStockStatus(item) === "low_stock"
  ).length;
  const outOfStockItems = items.filter(
    (item) => getStockStatus(item) === "out_of_stock"
  ).length;
  const totalQuantity = items.reduce((sum, item) => sum + item.quantity, 0);

  const categoryStats = CATEGORIES.map((cat) => {
    const catItems = items.filter((item) => item.category === cat.id);
    return {
      ...cat,
      count: catItems.length,
      quantity: catItems.reduce((sum, item) => sum + item.quantity, 0),
    };
  }).filter((cat) => cat.count > 0);

  const lastUpdated = items.length > 0
    ? new Date(
        Math.max(...items.map((item) => new Date(item.updatedAt).getTime()))
      ).toLocaleDateString("pt-BR", {
        day: "2-digit",
        month: "short",
        hour: "2-digit",
        minute: "2-digit",
      })
    : "-";

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: theme.backgroundRoot }]}
      contentContainerStyle={[
        styles.content,
        {
          paddingTop: headerHeight + Spacing.xl,
          paddingBottom: tabBarHeight + Spacing.xl,
        },
      ]}
      scrollIndicatorInsets={{ bottom: insets.bottom }}
      refreshControl={
        <RefreshControl
          refreshing={refreshing}
          onRefresh={handleRefresh}
          tintColor={theme.primary}
          progressViewOffset={headerHeight}
        />
      }
    >
      <Animated.View entering={FadeInDown.delay(0).duration(400)}>
        <ThemedText style={styles.sectionTitle}>Resumo do Estoque</ThemedText>
        <View style={styles.summaryRow}>
          <SummaryCard
            title="Total de Itens"
            value={totalItems}
            icon="package"
          />
          <View style={styles.summaryGap} />
          <SummaryCard
            title="Unidades"
            value={totalQuantity}
            icon="layers"
          />
        </View>
      </Animated.View>

      <Animated.View entering={FadeInDown.delay(100).duration(400)}>
        <View style={styles.summaryRow}>
          <SummaryCard
            title="Estoque Baixo"
            value={lowStockItems}
            icon="alert-triangle"
            color={theme.warning}
          />
          <View style={styles.summaryGap} />
          <SummaryCard
            title="Sem Estoque"
            value={outOfStockItems}
            icon="x-circle"
            color={theme.error}
          />
        </View>
      </Animated.View>

      {categoryStats.length > 0 ? (
        <Animated.View entering={FadeInDown.delay(200).duration(400)}>
          <ThemedText style={styles.sectionTitle}>Por Categoria</ThemedText>
          <View
            style={[
              styles.categoryCard,
              {
                backgroundColor: theme.backgroundDefault,
                borderColor: theme.cardBorder,
              },
            ]}
          >
            {categoryStats.map((cat, index) => (
              <View
                key={cat.id}
                style={[
                  styles.categoryRow,
                  index < categoryStats.length - 1 && {
                    borderBottomWidth: 1,
                    borderBottomColor: theme.border,
                  },
                ]}
              >
                <ThemedText style={styles.categoryName}>{cat.name}</ThemedText>
                <View style={styles.categoryStats}>
                  <ThemedText
                    style={[styles.categoryValue, { color: theme.textSecondary }]}
                  >
                    {cat.count} {cat.count === 1 ? "item" : "itens"}
                  </ThemedText>
                  <ThemedText style={styles.categoryQuantity}>
                    {cat.quantity} un.
                  </ThemedText>
                </View>
              </View>
            ))}
          </View>
        </Animated.View>
      ) : null}

      <Animated.View entering={FadeInDown.delay(300).duration(400)}>
        <View
          style={[
            styles.lastUpdated,
            { backgroundColor: theme.backgroundSecondary },
          ]}
        >
          <ThemedText
            style={[styles.lastUpdatedLabel, { color: theme.textSecondary }]}
          >
            Última atualização
          </ThemedText>
          <ThemedText style={styles.lastUpdatedValue}>{lastUpdated}</ThemedText>
        </View>
      </Animated.View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    paddingHorizontal: Spacing.lg,
  },
  sectionTitle: {
    fontSize: 14,
    fontWeight: "600",
    textTransform: "uppercase",
    letterSpacing: 0.5,
    marginBottom: Spacing.md,
    marginTop: Spacing.lg,
    opacity: 0.6,
  },
  summaryRow: {
    flexDirection: "row",
    marginBottom: Spacing.md,
  },
  summaryGap: {
    width: Spacing.md,
  },
  categoryCard: {
    borderRadius: BorderRadius.sm,
    borderWidth: 1,
    overflow: "hidden",
  },
  categoryRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
  },
  categoryName: {
    fontSize: 16,
    fontWeight: "500",
  },
  categoryStats: {
    alignItems: "flex-end",
  },
  categoryValue: {
    fontSize: 13,
    marginBottom: 2,
  },
  categoryQuantity: {
    fontSize: 16,
    fontWeight: "600",
  },
  lastUpdated: {
    marginTop: Spacing["2xl"],
    padding: Spacing.lg,
    borderRadius: BorderRadius.sm,
    alignItems: "center",
  },
  lastUpdatedLabel: {
    fontSize: 12,
    marginBottom: 4,
  },
  lastUpdatedValue: {
    fontSize: 16,
    fontWeight: "500",
  },
});
