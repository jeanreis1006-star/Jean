import React, { useState, useCallback, useEffect } from "react";
import { View, FlatList, StyleSheet, RefreshControl } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { useBottomTabBarHeight } from "@react-navigation/bottom-tabs";
import { useNavigation, useFocusEffect } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import Animated, { FadeInDown } from "react-native-reanimated";

import { SearchBar } from "@/components/SearchBar";
import { InventoryCard } from "@/components/InventoryCard";
import { FAB } from "@/components/FAB";
import { EmptyState } from "@/components/EmptyState";
import { InventoryListSkeleton } from "@/components/LoadingSkeleton";
import { useTheme } from "@/hooks/useTheme";
import { Spacing } from "@/constants/theme";
import { InventoryItem } from "@/types/inventory";
import { getInventory } from "@/lib/storage";
import { RootStackParamList } from "@/navigation/RootStackNavigator";

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;

export default function InventoryScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const tabBarHeight = useBottomTabBarHeight();
  const navigation = useNavigation<NavigationProp>();
  const { theme } = useTheme();

  const [items, setItems] = useState<InventoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const loadItems = useCallback(async () => {
    try {
      const data = await getInventory();
      setItems(data);
    } catch (error) {
      console.error("Error loading inventory:", error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      loadItems();
    }, [loadItems])
  );

  const handleRefresh = () => {
    setRefreshing(true);
    loadItems();
  };

  const filteredItems = items.filter((item) => {
    const query = searchQuery.toLowerCase();
    return (
      item.name.toLowerCase().includes(query) ||
      item.sku.toLowerCase().includes(query) ||
      item.location.toLowerCase().includes(query)
    );
  });

  const handleItemPress = (item: InventoryItem) => {
    navigation.navigate("ItemDetail", { itemId: item.id });
  };

  const handleAddPress = () => {
    navigation.navigate("AddItem");
  };

  const renderItem = ({ item, index }: { item: InventoryItem; index: number }) => (
    <Animated.View entering={FadeInDown.delay(index * 50).duration(300)}>
      <InventoryCard item={item} onPress={() => handleItemPress(item)} />
    </Animated.View>
  );

  const renderEmpty = () => {
    if (loading) {
      return <InventoryListSkeleton />;
    }

    if (searchQuery.length > 0) {
      return (
        <EmptyState
          title="Nenhum item encontrado"
          message={`Não encontramos itens correspondentes a "${searchQuery}"`}
          showImage={false}
        />
      );
    }

    return (
      <EmptyState
        title="Estoque vazio"
        message="Adicione o primeiro item ao seu inventário para começar a gerenciar seu estoque."
        actionLabel="Adicionar Item"
        onAction={handleAddPress}
      />
    );
  };

  return (
    <View style={[styles.container, { backgroundColor: theme.backgroundRoot }]}>
      <FlatList
        style={styles.list}
        contentContainerStyle={[
          styles.content,
          {
            paddingTop: headerHeight + Spacing.xl,
            paddingBottom: tabBarHeight + Spacing["5xl"],
          },
        ]}
        scrollIndicatorInsets={{ bottom: insets.bottom }}
        data={loading ? [] : filteredItems}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        ListHeaderComponent={
          <SearchBar
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholder="Buscar por nome, SKU ou local..."
          />
        }
        ListEmptyComponent={renderEmpty}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={handleRefresh}
            tintColor={theme.primary}
            progressViewOffset={headerHeight}
          />
        }
        showsVerticalScrollIndicator={false}
      />

      <FAB
        onPress={handleAddPress}
        style={{
          right: Spacing.lg,
          bottom: tabBarHeight + Spacing.lg,
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  list: {
    flex: 1,
  },
  content: {
    paddingHorizontal: Spacing.lg,
    flexGrow: 1,
  },
});
