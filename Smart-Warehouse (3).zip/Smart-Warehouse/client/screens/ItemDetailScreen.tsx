import React, { useState, useEffect, useCallback } from "react";
import { View, StyleSheet, Alert, Pressable } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { useNavigation, useRoute, RouteProp } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";

import { KeyboardAwareScrollViewCompat } from "@/components/KeyboardAwareScrollViewCompat";
import { FormInput } from "@/components/FormInput";
import { SelectInput } from "@/components/SelectInput";
import { QuantityStepper } from "@/components/QuantityStepper";
import { StatusBadge } from "@/components/StatusBadge";
import { ThemedText } from "@/components/ThemedText";
import { Button } from "@/components/Button";
import { Skeleton } from "@/components/LoadingSkeleton";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius } from "@/constants/theme";
import { InventoryItem, CATEGORIES, LOCATIONS, getStockStatus } from "@/types/inventory";
import { getInventory, updateItem, deleteItem } from "@/lib/storage";
import { RootStackParamList } from "@/navigation/RootStackNavigator";

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;
type RouteType = RouteProp<RootStackParamList, "ItemDetail">;

export default function ItemDetailScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const navigation = useNavigation<NavigationProp>();
  const route = useRoute<RouteType>();
  const { theme } = useTheme();

  const [item, setItem] = useState<InventoryItem | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [isEditing, setIsEditing] = useState(false);

  const [name, setName] = useState("");
  const [category, setCategory] = useState("");
  const [location, setLocation] = useState("");
  const [quantity, setQuantity] = useState(0);
  const [minQuantity, setMinQuantity] = useState(5);
  const [supplier, setSupplier] = useState("");
  const [notes, setNotes] = useState("");

  const loadItem = useCallback(async () => {
    try {
      const items = await getInventory();
      const found = items.find((i) => i.id === route.params.itemId);
      if (found) {
        setItem(found);
        setName(found.name);
        setCategory(found.category);
        setLocation(found.location);
        setQuantity(found.quantity);
        setMinQuantity(found.minQuantity);
        setSupplier(found.supplier || "");
        setNotes(found.notes || "");
      }
    } catch (error) {
      console.error("Error loading item:", error);
    } finally {
      setLoading(false);
    }
  }, [route.params.itemId]);

  useEffect(() => {
    loadItem();
  }, [loadItem]);

  const categoryOptions = CATEGORIES.map((cat) => ({
    value: cat.id,
    label: cat.name,
    icon: cat.icon as keyof typeof Feather.glyphMap,
  }));

  const locationOptions = LOCATIONS.map((loc) => ({
    value: loc,
    label: loc,
  }));

  const handleSave = async () => {
    if (!name.trim()) {
      Alert.alert("Erro", "Por favor, insira o nome do item.");
      return;
    }

    setSaving(true);
    try {
      await updateItem(route.params.itemId, {
        name: name.trim(),
        category,
        location,
        quantity,
        minQuantity,
        supplier: supplier.trim() || undefined,
        notes: notes.trim() || undefined,
      });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setIsEditing(false);
      loadItem();
    } catch (error) {
      console.error("Error saving item:", error);
      Alert.alert("Erro", "Não foi possível salvar o item.");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = () => {
    Alert.alert(
      "Excluir Item",
      `Tem certeza que deseja excluir "${item?.name}"? Esta ação não pode ser desfeita.`,
      [
        { text: "Cancelar", style: "cancel" },
        {
          text: "Excluir",
          style: "destructive",
          onPress: async () => {
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
            await deleteItem(route.params.itemId);
            navigation.goBack();
          },
        },
      ]
    );
  };

  React.useLayoutEffect(() => {
    navigation.setOptions({
      headerTitle: loading ? "Carregando..." : item?.name || "Item",
      headerRight: () =>
        !loading && item ? (
          <Pressable
            onPress={() => {
              if (isEditing) {
                handleSave();
              } else {
                setIsEditing(true);
              }
            }}
            disabled={saving}
            style={({ pressed }) => ({ opacity: pressed || saving ? 0.5 : 1 })}
            hitSlop={8}
            testID="button-edit-save"
          >
            <ThemedText style={{ color: theme.primary, fontWeight: "600" }}>
              {isEditing ? (saving ? "Salvando..." : "Salvar") : "Editar"}
            </ThemedText>
          </Pressable>
        ) : null,
    });
  }, [navigation, loading, item, isEditing, saving, name, quantity]);

  if (loading) {
    return (
      <View
        style={[
          styles.container,
          { backgroundColor: theme.backgroundRoot, paddingTop: headerHeight + Spacing.xl },
        ]}
      >
        <View style={{ paddingHorizontal: Spacing.lg }}>
          <Skeleton height={100} style={{ marginBottom: Spacing.lg }} />
          <Skeleton height={200} style={{ marginBottom: Spacing.lg }} />
          <Skeleton height={150} />
        </View>
      </View>
    );
  }

  if (!item) {
    return (
      <View
        style={[
          styles.container,
          styles.centered,
          { backgroundColor: theme.backgroundRoot },
        ]}
      >
        <ThemedText>Item não encontrado</ThemedText>
      </View>
    );
  }

  const status = getStockStatus(item);

  return (
    <KeyboardAwareScrollViewCompat
      style={[styles.container, { backgroundColor: theme.backgroundRoot }]}
      contentContainerStyle={[
        styles.content,
        {
          paddingTop: headerHeight + Spacing.xl,
          paddingBottom: insets.bottom + Spacing.xl,
        },
      ]}
    >
      <View
        style={[
          styles.section,
          {
            backgroundColor: theme.backgroundDefault,
            borderColor: theme.cardBorder,
          },
        ]}
      >
        <View style={styles.headerRow}>
          <View style={styles.skuContainer}>
            <ThemedText style={[styles.skuLabel, { color: theme.textSecondary }]}>
              SKU
            </ThemedText>
            <ThemedText style={styles.skuValue}>{item.sku}</ThemedText>
          </View>
          <StatusBadge status={status} />
        </View>
      </View>

      <View
        style={[
          styles.section,
          {
            backgroundColor: theme.backgroundDefault,
            borderColor: theme.cardBorder,
          },
        ]}
      >
        <ThemedText style={[styles.sectionTitle, { color: theme.textSecondary }]}>
          Informações Básicas
        </ThemedText>

        {isEditing ? (
          <>
            <FormInput
              label="Nome do Item"
              value={name}
              onChangeText={setName}
              autoCapitalize="words"
              testID="input-name"
            />
            <SelectInput
              label="Categoria"
              value={category}
              options={categoryOptions}
              onChange={setCategory}
            />
            <SelectInput
              label="Localização"
              value={location}
              options={locationOptions}
              onChange={setLocation}
            />
          </>
        ) : (
          <>
            <View style={styles.infoRow}>
              <ThemedText style={[styles.infoLabel, { color: theme.textSecondary }]}>
                Nome
              </ThemedText>
              <ThemedText style={styles.infoValue}>{item.name}</ThemedText>
            </View>
            <View style={styles.infoRow}>
              <ThemedText style={[styles.infoLabel, { color: theme.textSecondary }]}>
                Categoria
              </ThemedText>
              <ThemedText style={styles.infoValue}>
                {CATEGORIES.find((c) => c.id === item.category)?.name || item.category}
              </ThemedText>
            </View>
            <View style={styles.infoRow}>
              <ThemedText style={[styles.infoLabel, { color: theme.textSecondary }]}>
                Localização
              </ThemedText>
              <ThemedText style={styles.infoValue}>{item.location}</ThemedText>
            </View>
          </>
        )}
      </View>

      <View
        style={[
          styles.section,
          {
            backgroundColor: theme.backgroundDefault,
            borderColor: theme.cardBorder,
          },
        ]}
      >
        <ThemedText style={[styles.sectionTitle, { color: theme.textSecondary }]}>
          Quantidade
        </ThemedText>

        {isEditing ? (
          <>
            <QuantityStepper
              label="Quantidade Atual"
              value={quantity}
              onChange={setQuantity}
              min={0}
            />
            <QuantityStepper
              label="Quantidade Mínima"
              value={minQuantity}
              onChange={setMinQuantity}
              min={0}
            />
          </>
        ) : (
          <>
            <View style={styles.infoRow}>
              <ThemedText style={[styles.infoLabel, { color: theme.textSecondary }]}>
                Quantidade Atual
              </ThemedText>
              <ThemedText style={styles.infoValue}>{item.quantity} un.</ThemedText>
            </View>
            <View style={styles.infoRow}>
              <ThemedText style={[styles.infoLabel, { color: theme.textSecondary }]}>
                Quantidade Mínima
              </ThemedText>
              <ThemedText style={styles.infoValue}>{item.minQuantity} un.</ThemedText>
            </View>
          </>
        )}
      </View>

      <View
        style={[
          styles.section,
          {
            backgroundColor: theme.backgroundDefault,
            borderColor: theme.cardBorder,
          },
        ]}
      >
        <ThemedText style={[styles.sectionTitle, { color: theme.textSecondary }]}>
          Informações Adicionais
        </ThemedText>

        {isEditing ? (
          <>
            <FormInput
              label="Fornecedor"
              value={supplier}
              onChangeText={setSupplier}
              placeholder="Nome do fornecedor (opcional)"
              testID="input-supplier"
            />
            <FormInput
              label="Observações"
              value={notes}
              onChangeText={setNotes}
              placeholder="Notas adicionais (opcional)"
              multiline
              numberOfLines={3}
              style={styles.notesInput}
              testID="input-notes"
            />
          </>
        ) : (
          <>
            <View style={styles.infoRow}>
              <ThemedText style={[styles.infoLabel, { color: theme.textSecondary }]}>
                Fornecedor
              </ThemedText>
              <ThemedText style={styles.infoValue}>
                {item.supplier || "-"}
              </ThemedText>
            </View>
            <View style={styles.infoRow}>
              <ThemedText style={[styles.infoLabel, { color: theme.textSecondary }]}>
                Observações
              </ThemedText>
              <ThemedText style={styles.infoValue}>
                {item.notes || "-"}
              </ThemedText>
            </View>
          </>
        )}
      </View>

      <View style={styles.metaSection}>
        <ThemedText style={[styles.metaText, { color: theme.textSecondary }]}>
          Criado em: {new Date(item.createdAt).toLocaleDateString("pt-BR")}
        </ThemedText>
        <ThemedText style={[styles.metaText, { color: theme.textSecondary }]}>
          Atualizado em: {new Date(item.updatedAt).toLocaleDateString("pt-BR")}
        </ThemedText>
      </View>

      <View style={styles.deleteSection}>
        <Pressable
          onPress={handleDelete}
          style={({ pressed }) => [
            styles.deleteButton,
            { opacity: pressed ? 0.6 : 1 },
          ]}
          testID="button-delete"
        >
          <Feather name="trash-2" size={18} color={theme.error} />
          <ThemedText style={[styles.deleteText, { color: theme.error }]}>
            Excluir Item
          </ThemedText>
        </Pressable>
      </View>
    </KeyboardAwareScrollViewCompat>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  centered: {
    alignItems: "center",
    justifyContent: "center",
  },
  content: {
    paddingHorizontal: Spacing.lg,
  },
  section: {
    borderRadius: BorderRadius.sm,
    borderWidth: 1,
    padding: Spacing.lg,
    marginBottom: Spacing.lg,
  },
  headerRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  skuContainer: {},
  skuLabel: {
    fontSize: 12,
    marginBottom: 2,
  },
  skuValue: {
    fontSize: 18,
    fontWeight: "600",
    letterSpacing: 1,
  },
  sectionTitle: {
    fontSize: 13,
    fontWeight: "600",
    textTransform: "uppercase",
    letterSpacing: 0.5,
    marginBottom: Spacing.lg,
  },
  infoRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: Spacing.sm,
  },
  infoLabel: {
    fontSize: 15,
  },
  infoValue: {
    fontSize: 15,
    fontWeight: "500",
  },
  notesInput: {
    height: 80,
    textAlignVertical: "top",
    paddingTop: Spacing.md,
  },
  metaSection: {
    paddingVertical: Spacing.md,
    alignItems: "center",
  },
  metaText: {
    fontSize: 12,
    marginBottom: 4,
  },
  deleteSection: {
    alignItems: "center",
    paddingVertical: Spacing.lg,
  },
  deleteButton: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.lg,
  },
  deleteText: {
    fontSize: 16,
    fontWeight: "500",
    marginLeft: Spacing.sm,
  },
});
