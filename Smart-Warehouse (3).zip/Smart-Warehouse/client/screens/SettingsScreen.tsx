import React, { useState, useCallback } from "react";
import { View, ScrollView, StyleSheet, Alert, Image } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { useBottomTabBarHeight } from "@react-navigation/bottom-tabs";
import { useFocusEffect } from "@react-navigation/native";
import * as Haptics from "expo-haptics";

import { SettingsRow } from "@/components/SettingsRow";
import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius } from "@/constants/theme";
import { getSettings, saveSettings, clearAllData, AppSettings } from "@/lib/storage";

export default function SettingsScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const tabBarHeight = useBottomTabBarHeight();
  const { theme } = useTheme();

  const [settings, setSettings] = useState<AppSettings>({
    lowStockThreshold: 5,
    notificationsEnabled: true,
    warehouseName: "Almoxarifado Principal",
    userName: "Usuário",
  });

  const loadSettings = useCallback(async () => {
    try {
      const data = await getSettings();
      setSettings(data);
    } catch (error) {
      console.error("Error loading settings:", error);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      loadSettings();
    }, [loadSettings])
  );

  const handleToggleNotifications = async (value: boolean) => {
    const updated = await saveSettings({ notificationsEnabled: value });
    setSettings(updated);
  };

  const handleClearData = () => {
    Alert.alert(
      "Limpar Dados",
      "Tem certeza que deseja apagar todos os dados do aplicativo? Esta ação não pode ser desfeita.",
      [
        { text: "Cancelar", style: "cancel" },
        {
          text: "Apagar Tudo",
          style: "destructive",
          onPress: async () => {
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
            await clearAllData();
            loadSettings();
          },
        },
      ]
    );
  };

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: theme.backgroundRoot }]}
      contentContainerStyle={[
        styles.content,
        {
          paddingTop: headerHeight + Spacing.xl,
          paddingBottom: tabBarHeight + Spacing.xl,
        },
      ]}
      scrollIndicatorInsets={{ bottom: insets.bottom }}
    >
      <View style={styles.profileSection}>
        <Image
          source={require("../../assets/images/avatar-default.png")}
          style={styles.avatar}
        />
        <ThemedText style={styles.userName}>{settings.userName}</ThemedText>
        <ThemedText style={[styles.warehouseName, { color: theme.textSecondary }]}>
          {settings.warehouseName}
        </ThemedText>
      </View>

      <ThemedText style={[styles.sectionTitle, { color: theme.textSecondary }]}>
        Preferências
      </ThemedText>
      <View
        style={[
          styles.section,
          {
            backgroundColor: theme.backgroundDefault,
            borderColor: theme.cardBorder,
          },
        ]}
      >
        <SettingsRow
          icon="bell"
          title="Notificações"
          subtitle="Alertas de estoque baixo"
          toggle
          toggleValue={settings.notificationsEnabled}
          onToggle={handleToggleNotifications}
        />
        <View style={[styles.divider, { backgroundColor: theme.border }]} />
        <SettingsRow
          icon="alert-circle"
          title="Limite de Estoque Baixo"
          value={`${settings.lowStockThreshold} un.`}
        />
      </View>

      <ThemedText style={[styles.sectionTitle, { color: theme.textSecondary }]}>
        Informações
      </ThemedText>
      <View
        style={[
          styles.section,
          {
            backgroundColor: theme.backgroundDefault,
            borderColor: theme.cardBorder,
          },
        ]}
      >
        <SettingsRow
          icon="info"
          title="Sobre o App"
          subtitle="Versão 1.0.0"
        />
        <View style={[styles.divider, { backgroundColor: theme.border }]} />
        <SettingsRow
          icon="help-circle"
          title="Ajuda"
          onPress={() => {}}
        />
      </View>

      <ThemedText style={[styles.sectionTitle, { color: theme.textSecondary }]}>
        Dados
      </ThemedText>
      <View
        style={[
          styles.section,
          {
            backgroundColor: theme.backgroundDefault,
            borderColor: theme.cardBorder,
          },
        ]}
      >
        <SettingsRow
          icon="trash-2"
          title="Limpar Todos os Dados"
          subtitle="Remove todos os itens e configurações"
          onPress={handleClearData}
          destructive
        />
      </View>

      <View style={styles.footer}>
        <ThemedText style={[styles.footerText, { color: theme.textSecondary }]}>
          Almoxarifado Inteligente
        </ThemedText>
        <ThemedText style={[styles.footerText, { color: theme.textSecondary }]}>
          Desenvolvido com React Native
        </ThemedText>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    paddingHorizontal: Spacing.lg,
  },
  profileSection: {
    alignItems: "center",
    paddingVertical: Spacing["2xl"],
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    marginBottom: Spacing.md,
  },
  userName: {
    fontSize: 22,
    fontWeight: "600",
    marginBottom: 4,
  },
  warehouseName: {
    fontSize: 15,
  },
  sectionTitle: {
    fontSize: 13,
    fontWeight: "600",
    textTransform: "uppercase",
    letterSpacing: 0.5,
    marginBottom: Spacing.sm,
    marginTop: Spacing.lg,
    marginLeft: Spacing.xs,
  },
  section: {
    borderRadius: BorderRadius.sm,
    borderWidth: 1,
    paddingHorizontal: Spacing.lg,
  },
  divider: {
    height: 1,
    marginLeft: 52,
  },
  footer: {
    alignItems: "center",
    paddingVertical: Spacing["3xl"],
  },
  footerText: {
    fontSize: 13,
    marginBottom: 4,
  },
});
