# Almoxarifado Inteligente

## Overview
**Almoxarifado Inteligente** is a warehouse inventory management mobile app built with React Native (Expo) and Express.js. The app allows users to track stock levels, manage inventory items, and view reports - all in Portuguese (pt-BR).

## Key Features
- **Inventory Management**: Add, edit, delete, and search inventory items
- **Stock Status Tracking**: Visual indicators for in-stock (green), low-stock (amber), and out-of-stock (red) items
- **Reports Dashboard**: View inventory statistics and category breakdowns
- **Local Storage**: Data persisted using AsyncStorage (no backend database required for MVP)

## Project Architecture

### Tech Stack
- **Frontend**: React Native with Expo
- **Backend**: Express.js (minimal - mainly for static landing page)
- **Data Storage**: AsyncStorage (local device storage)
- **Navigation**: React Navigation v7 with bottom tabs
- **State Management**: React Query + local state
- **Styling**: StyleSheet with custom theme system

### Directory Structure
```
client/
├── components/          # Reusable UI components
│   ├── StatusBadge.tsx  # Stock status indicators
│   ├── InventoryCard.tsx # Item list cards
│   ├── SearchBar.tsx    # Search input with filter
│   ├── FAB.tsx          # Floating action button
│   ├── EmptyState.tsx   # Empty list illustration
│   ├── FormInput.tsx    # Text input with label
│   ├── SelectInput.tsx  # Dropdown selector
│   ├── QuantityStepper.tsx # +/- quantity control
│   └── ...
├── screens/             # App screens
│   ├── InventoryScreen.tsx  # Main inventory list
│   ├── ItemDetailScreen.tsx # View/edit item
│   ├── AddItemScreen.tsx    # Add new item modal
│   ├── ReportsScreen.tsx    # Analytics dashboard
│   └── SettingsScreen.tsx   # App settings
├── navigation/          # Navigation configuration
├── lib/                 # Utilities
│   └── storage.ts       # AsyncStorage operations
├── types/               # TypeScript types
│   └── inventory.ts     # Item, Category, Status types
└── constants/
    └── theme.ts         # Colors, spacing, typography
```

### Color Palette
- **Primary**: #0066CC (trustworthy blue)
- **Background**: #F5F7FA (soft cool gray)
- **Success**: #00A86B (in-stock green)
- **Warning**: #F59E0B (low-stock amber)
- **Error**: #DC2626 (out-of-stock red)

### Data Model
```typescript
interface InventoryItem {
  id: string;
  name: string;
  sku: string;           // Auto-generated "ALM-XXXXXX"
  quantity: number;
  minQuantity: number;   // Triggers low-stock alert
  category: string;
  location: string;
  supplier?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}
```

## Development

### Running the App
1. **Frontend**: `npm run expo:dev` (port 8081)
2. **Backend**: `npm run server:dev` (port 5000)

### Testing
- Use Expo Go app on physical device to scan QR code
- Web version available but may differ from native experience

## Recent Changes
- Initial MVP implementation with complete inventory CRUD
- Three-tab navigation: Inventário, Relatórios, Configurações
- FAB for quick item addition
- Search and filter functionality
- Status badges for stock levels
- Reports with category breakdown
- Settings with data management options
